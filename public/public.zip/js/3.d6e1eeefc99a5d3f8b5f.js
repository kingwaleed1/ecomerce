(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[3],{

/***/ 438:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
 // Just add this feature if you want :P

var UserOrdersTab = function UserOrdersTab() {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    className: "loader",
    style: {
      minHeight: '80vh'
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h3", null, "My Orders"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("strong", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
    className: "text-subtle"
  }, "You don't have any orders")));
};

/* harmony default export */ __webpack_exports__["default"] = (UserOrdersTab);

/***/ })

}]);
//# sourceMappingURL=3.d6e1eeefc99a5d3f8b5f.js.map